CREATE OR REPLACE FUNCTION process_btc_data()
RETURNS VOID LANGUAGE plpython3u AS $$
import pandas as pd
from arch import arch_model
import numpy as np

# Fetch raw BTC prices from the database
query = plpy.execute("SELECT timestamp, price FROM btc_usd_prices ORDER BY timestamp")
prices = {row["timestamp"]: float(row["price"]) for row in query}

# Convert to DataFrame
df = pd.DataFrame(list(prices.items()), columns=["timestamp", "price"])
df["timestamp"] = pd.to_datetime(df["timestamp"])

# Step 1: Calculate Log Returns
df["returns"] = np.log(df["price"]).diff()

# Step 2: Handle Outliers and NaN/Inf Values
df["returns"] = df["returns"].clip(lower=-0.2, upper=0.2)  # Cap at ±20%
df = df.replace([np.inf, -np.inf], np.nan).dropna(subset=["returns"])  # Remove inf and NaN values

# Debug: Log cleaned returns
plpy.info(f"Cleaned Returns:\n{df[['timestamp', 'returns']]}")

# Step 3: Calculate Realized Volatility (RV)
window_size = min(10, len(df))  # Adjust rolling window size dynamically
df["rv"] = df["returns"].rolling(window=window_size).std() * (365**0.5)  # Annualized RV

# Debug: Log RV calculations
plpy.info(f"RV Calculations:\n{df[['timestamp', 'rv']]}")

# Step 4: Apply GARCH Model
if len(df) >= 10:  # Minimum requirement for GARCH
    garch_model = arch_model(df["returns"] * 100, vol="Garch", p=1, q=1)
    try:
        res = garch_model.fit(disp="off")
        df["garch_iv"] = res.conditional_volatility / 100  # Convert to decimal
    except Exception as e:
        plpy.info(f"GARCH model fitting failed: {e}")
        df["garch_iv"] = None
else:
    plpy.info("Insufficient data for GARCH model. Setting garch_iv to NULL for all rows.")
    df["garch_iv"] = None

# Debug: Log GARCH IV calculations
plpy.info(f"GARCH IV Calculations:\n{df[['timestamp', 'garch_iv']]}")

# Step 5: Insert Results into btc_usd_processed Table
for _, row in df.iterrows():
    rv_value = None if pd.isna(row["rv"]) else row["rv"]
    garch_iv_value = None if pd.isna(row["garch_iv"]) else row["garch_iv"]

    # Construct and execute the query
    query = f"""
        INSERT INTO btc_usd_processed (timestamp, rv, garch_iv)
        VALUES ('{row["timestamp"].date()}', {rv_value if rv_value is not None else 'NULL'}, {garch_iv_value if garch_iv_value is not None else 'NULL'})
        ON CONFLICT (timestamp) DO UPDATE
        SET rv = EXCLUDED.rv, garch_iv = EXCLUDED.garch_iv
    """
    plpy.execute(query)
$$;

