//mod arch_handler;
mod websocket;

use actix_web::{web, App, HttpServer, HttpResponse, Responder, HttpRequest};
use actix_web_actors::ws;
use actix_cors::Cors;
//use arch_handler::ArchHandler;
use log::{info, error};
use serde::{Serialize, Deserialize};
use crate::websocket::WebSocketSession;

#[derive(Debug, Serialize, Deserialize)]
struct HistoricalData {
    iv: f64,
    iv_price: f64,
    timestamp: f64,
}

async fn test() -> impl Responder {
    HttpResponse::Ok().body("Server is running")
}

async fn health() -> impl Responder {
    HttpResponse::Ok().body("OK")
}

async fn historical(query: web::Query<HistoricalQuery>) -> impl Responder {
    info!("Received historical data request with limit: {:?}", query.limit);
    
    // Mock data for testing
    let now = chrono::Utc::now().timestamp_millis() as f64;
    let mut data = vec![
        HistoricalData {
            iv: 0.65,
            iv_price: 0.05,
            timestamp: now - 3600000.0, // 1 hour ago
        },
        HistoricalData {
            iv: 0.68,
            iv_price: 0.052,
            timestamp: now - 1800000.0, // 30 mins ago
        },
        HistoricalData {
            iv: 0.70,
            iv_price: 0.054,
            timestamp: now,
        },
    ];

    // If limit is specified, return only the last n items
    if let Some(limit) = query.limit {
        data.truncate(limit);
        info!("Returning {} records", limit);
    } else {
        info!("Returning all {} records", data.len());
    }

    HttpResponse::Ok().json(data)
}

async fn ws_route(req: HttpRequest, stream: web::Payload) -> Result<HttpResponse, actix_web::Error> {
    info!("WebSocket connection request received");
    ws::start(WebSocketSession::new(), &req, stream)
}

#[derive(Debug, Deserialize)]
struct HistoricalQuery {
    limit: Option<usize>,
}

// Request and response structures
#[derive(Debug, Deserialize)]
struct MintRequest {
    btc_amount: f64,
    iv_price: f64,
    wallet_address: String,
}

#[derive(Debug, Deserialize)]
struct BurnRequest {
    vlx_amount: f64,
    iv_price: f64,
    wallet_address: String,
}

#[derive(Debug, Serialize)]
struct TransactionResponse {
    tx_hash: String,
    status: String,
}

// API handlers
async fn mint_vlxbtc(req: web::Json<MintRequest>) -> impl Responder {
    info!("Received mint request: {:?}", req);
    
    // Here you would integrate with Arch Network
    // For now, return a mock response
    let tx_hash = format!("mint_{}_{}_{}",
        req.btc_amount,
        req.iv_price,
        chrono::Utc::now().timestamp()
    );

    HttpResponse::Ok().json(TransactionResponse {
        tx_hash,
        status: "pending".to_string(),
    })
}

async fn burn_vlxbtc(req: web::Json<BurnRequest>) -> impl Responder {
    info!("Received burn request: {:?}", req);
    
    // Here you would integrate with Arch Network
    // For now, return a mock response
    let tx_hash = format!("burn_{}_{}_{}",
        req.vlx_amount,
        req.iv_price,
        chrono::Utc::now().timestamp()
    );

    HttpResponse::Ok().json(TransactionResponse {
        tx_hash,
        status: "pending".to_string(),
    })
}

#[actix_web::main]
async fn main() -> std::io::Result<()> {
    env_logger::init_from_env(env_logger::Env::new().default_filter_or("info"));
    
    info!("Starting server...");
    let host = "0.0.0.0";
    let port = 8080; // GCP's default HTTP port

    
    //let arch_handler = web::Data::new(ArchHandler::new());
    let server = HttpServer::new(move || {
        let cors = Cors::default()
            .allow_any_origin()
            .allow_any_method()
            .allow_any_header();

        App::new()
            .wrap(cors)
            //.app_data(arch_handler.clone())
            .route("/test", web::get().to(test))
            .route("/health", web::get().to(health))
            .route("/historical", web::get().to(historical))
            .route("/ws", web::get().to(ws_route))
            .service(
                web::scope("/api")
            )
    })
    .bind((host, port))?;

    info!("Server running at http://127.0.0.1:3030");
    info!("Available endpoints:");
    info!("  GET  /test");
    info!("  GET  /health");
    info!("  GET  /historical");
    info!("  GET  /ws");
    
    server.run().await
}


// backend/src/main.rs
//use actix_web::{web, App, HttpServer, HttpResponse};
//use tokio_postgres::{NoTls, Error};

/*async fn add_transaction(transaction: web::Json<Transaction>) -> Result<HttpResponse, Error> {
    let (client, connection) = tokio_postgres::connect(
        "host=localhost user=postgres dbname=vlxbtc",
        NoTls,
    ).await?;

    tokio::spawn(async move {
        if let Err(e) = connection.await {
            eprintln!("connection error: {}", e);
        }
    });

    client.execute(
        "INSERT INTO transactions (wallet_address, quantity, price, transaction_type, timestamp) 
         VALUES ($1, $2, $3, $4, $5)",
        &[
            &transaction.wallet_address,
            &transaction.quantity,
            &transaction.price,
            &transaction.transaction_type,
            &transaction.timestamp,
        ],
    ).await?;

    Ok(HttpResponse::Ok().json(transaction))
}*/
