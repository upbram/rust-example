import pandas as pd
import numpy as np
from datetime import datetime

# Stochastic volatility model
def stochastic_volatility(rv, alpha=0.01, beta=0.99):
    try:
        return alpha + beta * rv
    except Exception:
        return None

# Fetch all RV data
query = """
    SELECT rv, timestamp
    FROM volatility_metrics
    ORDER BY timestamp ASC
"""
rows = plpy.execute(query)

# Ensure data exists
if len(rows) == 0:
    plpy.notice("No data found in volatility_metrics.")
    return

# Extract RV data and timestamps
try:
    rv_data = [float(row['rv']) for row in rows]
    timestamps = [row['timestamp'] for row in rows]
    df = pd.DataFrame({'rv': rv_data, 'timestamp': timestamps})
except Exception as e:
    plpy.error(f"Error processing RV data: {e}")
    return

# Process each row to calculate IV and IV price
for index, row in df.iterrows():
    try:
        rv = row['rv']
        iv = stochastic_volatility(rv)  # Compute IV using Stochastic Volatility model
        if iv is None:
            continue

        # Fetch the latest BTC price
        btc_price_query = "SELECT price FROM btc_usd_prices ORDER BY timestamp DESC LIMIT 1"
        btc_row = plpy.execute(btc_price_query)
        btc_price = float(btc_row[0]['price']) if btc_row else None

        if btc_price is None:
            plpy.notice("BTC price not found; skipping IV price calculation.")
            continue

        iv_price = iv * 0.05 * btc_price

        # Convert types to ensure compatibility
        iv = float(iv)
        iv_price = float(iv_price)
        row_timestamp = str(row['timestamp'])  # Ensure timestamp is formatted correctly

        # Debugging: Construct and log the query for manual testing
        update_query = f"""
            UPDATE volatility_metrics
            SET iv = {iv}, iv_price = {iv_price}
            WHERE timestamp = '{row_timestamp}'
        """
        plpy.notice(f"Executing query: {update_query}")

        # Execute the query
        plpy.execute(update_query)

    except Exception as e:
        # Log the query that caused the error
        plpy.error(f"Error calculating IV for row {row.to_dict()} with query {update_query}: {e}")
                                                                                                   