CREATE OR REPLACE FUNCTION calculate_rv_wema()
RETURNS VOID AS $$
import numpy as np

def wema(values, alpha=0.94):
    """Weighted Exponential Moving Average."""
    weights = np.array([alpha ** i for i in range(len(values))][::-1])
    weights = weights / weights.sum()
    return np.sqrt(np.sum(weights * np.array(values)))

# Fetch BTC prices for RV calculation
query = """
    SELECT price, timestamp
    FROM btc_usd_prices
    WHERE timestamp >= (NOW() - INTERVAL '1 day')
    ORDER BY timestamp ASC
"""
rows = plpy.execute(query)

if len(rows) < 2:
    plpy.notice("Not enough data for RV calculation.")
    return

# Convert prices to float and calculate log returns
prices = [float(row['price']) for row in rows]
returns = np.diff(np.log(prices))
squared_returns = returns ** 2

# Calculate RV using WEMA
rv = wema(squared_returns)

# Insert or update RV in the volatility_metrics table
insert_query = """
    INSERT INTO volatility_metrics (timestamp, rv)
    VALUES (NOW(), %s)
    ON CONFLICT (timestamp) DO UPDATE SET rv = EXCLUDED.rv
"""
plpy.execute(insert_query % rv)
$$ LANGUAGE plpython3u;

