CREATE OR REPLACE FUNCTION calculate_iv_egarch()
RETURNS VOID AS $$
import pandas as pd
from arch import arch_model
import numpy as np
from datetime import datetime

# Fetch RV data with missing IV or IV Price
query = """
    SELECT rv, timestamp
    FROM volatility_metrics
    WHERE iv IS NULL OR iv_price IS NULL
    ORDER BY timestamp ASC
"""
rows = plpy.execute(query)

if len(rows) < 30 * 1440:  # Expecting 1440 data points per day
    plpy.notice("Not enough data points for IV calculation.")
    return

# Extract RV data and timestamps
try:
    rv_data = [float(row['rv']) for row in rows]
    timestamps = [row['timestamp'] for row in rows]
    df = pd.DataFrame({'rv': rv_data, 'timestamp': timestamps})
except Exception as e:
    plpy.error(f"Error processing RV data: {e}")
    return

# Fit EGARCH model
try:
    model = arch_model(df['rv'], vol='EGARCH', p=1, q=1)
    result = model.fit(disp="off")
except Exception as e:
    plpy.error(f"Error fitting EGARCH model: {e}")
    return

# Forecast variance and calculate IV for each row
for index, row in df.iterrows():
    try:
        forecast = result.forecast(horizon=1, reindex=False)
        iv = float(np.sqrt(forecast.variance.iloc[-1, 0]))  # Ensure compatibility with SQL

        # Fetch latest BTC price for IV price calculation
        btc_price_query = "SELECT price FROM btc_usd_prices ORDER BY timestamp DESC LIMIT 1"
        btc_row = plpy.execute(btc_price_query)
        btc_price = float(btc_row[0]['price']) if btc_row else None

        if btc_price is None:
            plpy.notice("BTC price not found; skipping IV price calculation.")
            continue

        iv_price = iv * 0.05 * btc_price

        # Convert timestamp to datetime object
        row_timestamp = datetime.strptime(str(row['timestamp']), '%Y-%m-%d %H:%M:%S.%f')

        # Debugging: Log query and parameters
        plpy.notice(f"Updating row: {row.to_dict()}")
        plpy.notice(f"IV: {iv}, IV Price: {iv_price}, Timestamp: {row_timestamp}")
        plpy.notice(f"Types: IV({type(iv)}), IV Price({type(iv_price)}), Timestamp({type(row_timestamp)})")

        # Explicitly construct the query string
        update_query = f"""
            UPDATE volatility_metrics
            SET iv = {iv}, iv_price = {iv_price}
            WHERE timestamp = '{row_timestamp.strftime('%Y-%m-%d %H:%M:%S.%f')}'
        """
        plpy.notice(f"Executing query: {update_query}")
        plpy.execute(update_query)

    except Exception as e:
        plpy.error(f"Error calculating IV for row {row.to_dict()}: {e}")

$$ LANGUAGE plpython3u;



