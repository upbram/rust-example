use actix::{Actor, StreamHandler};
use actix_web_actors::ws;
use log::info;
use serde_json::json;
use std::time::{Duration, Instant};
use actix::prelude::*;

const HEARTBEAT_INTERVAL: Duration = Duration::from_secs(5);
const CLIENT_TIMEOUT: Duration = Duration::from_secs(10);

pub struct WebSocketSession {
    hb: Instant,
}

impl WebSocketSession {
    pub fn new() -> Self {
        Self {
            hb: Instant::now(),
        }
    }

    fn heartbeat(&self, ctx: &mut ws::WebsocketContext<Self>) {
        ctx.run_interval(HEARTBEAT_INTERVAL, |act, ctx| {
            if Instant::now().duration_since(act.hb) > CLIENT_TIMEOUT {
                info!("WebSocket Client heartbeat failed, disconnecting!");
                ctx.stop();
                return;
            }

            ctx.ping(b"");
        });
    }
}

impl Actor for WebSocketSession {
    type Context = ws::WebsocketContext<Self>;

    fn started(&mut self, ctx: &mut Self::Context) {
        info!("WebSocket connection established");
        self.heartbeat(ctx);

        // Start sending periodic updates
        ctx.run_interval(Duration::from_secs(1), |_, ctx| {
            let now = chrono::Utc::now().timestamp_millis() as f64;
            let data = json!({
                "iv": 0.70 + (rand::random::<f64>() - 0.5) * 0.1,
                "iv_price": 0.054 + (rand::random::<f64>() - 0.5) * 0.002,
                "timestamp": now
            });
            
            ctx.text(data.to_string());
        });
    }
}

impl StreamHandler<Result<ws::Message, ws::ProtocolError>> for WebSocketSession {
    fn handle(&mut self, msg: Result<ws::Message, ws::ProtocolError>, ctx: &mut Self::Context) {
        match msg {
            Ok(ws::Message::Ping(msg)) => {
                self.hb = Instant::now();
                ctx.pong(&msg);
            }
            Ok(ws::Message::Pong(_)) => {
                self.hb = Instant::now();
            }
            Ok(ws::Message::Text(text)) => {
                info!("Received text message: {}", text);
                ctx.text(text);
            }
            Ok(ws::Message::Binary(bin)) => {
                info!("Received binary message: {:?}", bin);
                ctx.binary(bin);
            }
            Ok(ws::Message::Close(reason)) => {
                info!("Connection closed: {:?}", reason);
                ctx.close(reason);
                ctx.stop();
            }
            _ => (),
        }
    }
} 